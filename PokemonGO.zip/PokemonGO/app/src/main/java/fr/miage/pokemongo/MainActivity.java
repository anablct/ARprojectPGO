package fr.miage.pokemongo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    // on déclare notre bouton pour lancer le jeu afin de pouvoir interagir avec
    private Button mPlay_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mPlay_btn = (Button) findViewById(R.id.btnPlay);
        mPlay_btn.setOnClickListener(new View.OnClickListener()
                                     {
                                         @Override
                                         public void onClick (View view){
                                             Intent mapsActivity = new Intent(MainActivity.this,MapsActivity.class);
                                             startActivity(mapsActivity);

                                         }
                                     }
        );
    }

    // on lance une nouvelle activité qui va donner sur l'API


}

