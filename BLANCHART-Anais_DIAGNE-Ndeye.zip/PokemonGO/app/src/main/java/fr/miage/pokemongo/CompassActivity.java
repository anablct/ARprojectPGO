package fr.miage.pokemongo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class CompassActivity extends AppCompatActivity implements SensorEventListener {
    private ImageView compassImage;
    private TextView distanceText;
    private SensorManager sensorManager;
    private Sensor compassSensor;
    private float currentDegree = 0f;
    private LocationManager locationManager;

    private PokemonDatabaseHelper databaseHelper;
    private List<Location> pokemonLocations;
    private List<String> pokemonNames;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_compass);

        // Récupération de l'ImageView de la boussole et du TextView de la distance
        compassImage = (ImageView) findViewById(R.id.compass);
        distanceText = (TextView) findViewById(R.id.distance_text);

        // Récupération du capteur de boussole et enregistrement de l'activité comme écouteur
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        compassSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION);
        sensorManager.registerListener(this, compassSensor, SensorManager.SENSOR_DELAY_UI);

        // Récupération du gestionnaire de localisation et demande de mise à jour de la position
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, new LocationListener() {

            @Override
            public void onLocationChanged(Location location) {
                // Mise à jour de la distance de chaque Pokémon par rapport à l'utilisateur
                updateDistances(location);
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {
            }

            @Override
            public void onProviderEnabled(String provider) {
            }

            public void onProviderDisabled(String provider) {
            }
        });

        // Création de l'objet de base de données
        databaseHelper = new PokemonDatabaseHelper(this);

        // Récupération de la liste des positions de chaque Pokémon depuis la base de données
        pokemonLocations = getPokemonLocations();
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        // Mise à jour de l'angle de rotation de la boussole en fonction de la valeur de l'azimut
        float degree = Math.round(event.values[0]);
        RotateAnimation ra = new RotateAnimation(currentDegree, -degree,
                Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        ra.setDuration(210);
        ra.setFillAfter(true);
        compassImage.startAnimation(ra);
        currentDegree = -degree;
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    private void updateDistances(Location userLocation) {
        float minDistance = Float.MAX_VALUE;
        int minIndex = -1;
        for (int i = 0; i < pokemonLocations.size(); i++) {
            Location pokemonLocation = pokemonLocations.get(i);
            float distance = userLocation.distanceTo(pokemonLocation);
            // On affiche seulement le pokemon le plus proche de notre position
            if (distance < minDistance) {
                minDistance = distance;
                minIndex = i;
            }
        }
        // Si la distance est inférieure à 20 mètres, on affiche le Pokémon
        if (minIndex != -1 && minDistance < 20) {
            distanceText.setText(String.format("Distance de %s : %.2f mètres\n", pokemonNames.get(minIndex), minDistance));
            Toast.makeText(this, String.format("%s est proche !", pokemonNames.get(minIndex)), Toast.LENGTH_SHORT).show();
        }
    }

    private List<Location> getPokemonLocations() {
        // Récupération de la position de chaque Pokémon depuis la base de données
        List<Location> locations = new ArrayList<>();
        pokemonNames = new ArrayList<>();
        PokemonDatabaseHelper dbHelper = new PokemonDatabaseHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM pokemon", null);
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String name = cursor.getString(1);
                double latitude = cursor.getDouble(2);
                double longitude = cursor.getDouble(3);
                Location pokemonLocation = new Location("");
                pokemonLocation.setLatitude(latitude);
                pokemonLocation.setLongitude(longitude);
                locations.add(pokemonLocation);
                pokemonNames.add(name);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return locations;
    }
}