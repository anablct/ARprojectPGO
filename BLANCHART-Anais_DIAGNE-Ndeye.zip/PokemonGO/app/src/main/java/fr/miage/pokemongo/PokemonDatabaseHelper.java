package fr.miage.pokemongo;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class PokemonDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "pokemon";
    private static final int DATABASE_VERSION = 1;

    public PokemonDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Créez la table de Pokémon ici
        String createTableSql = "CREATE TABLE pokemon (id INTEGER PRIMARY KEY, name TEXT, latitude REAL, longitude REAL)";
        db.execSQL(createTableSql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Mettez à jour la table de Pokémon ici si nécessaire
        db.execSQL("DROP TABLE IF EXISTS pokemon");
        onCreate(db);
    }
}