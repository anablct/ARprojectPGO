package fr.miage.pokemongo;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.google.ar.sceneform.ux.ArFragment;


public class CameraActivity extends AppCompatActivity {

    private ArFragment arFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera);

        // On fait appel au flux de la camera
        arFragment = (ArFragment) getSupportFragmentManager().findFragmentById(R.id.ux_fragment);

    }
}

