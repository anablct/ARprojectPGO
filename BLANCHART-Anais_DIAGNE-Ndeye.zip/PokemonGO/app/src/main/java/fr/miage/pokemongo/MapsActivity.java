package fr.miage.pokemongo;
import android.Manifest;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationRequest;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    // On déclare les différentes variables que nous allons manipuler
    private static final int PERMS_CALL_ID = 1234 ;
    private GoogleMap gMap;
    private Boolean bool = false;
    private Button mCompass_btn;
    private Button mCamera_btn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);


        mCompass_btn = findViewById(R.id.btn_compass);
        mCamera_btn = findViewById(R.id.btn_camera);

        // On passe de l'activité MapsActivity à CompassActivity
        mCompass_btn.setOnClickListener(new View.OnClickListener()
                                     {
                                         @Override
                                         public void onClick (View view)
                                         {
                                             Intent compassActivity = new Intent(MapsActivity.this, CompassActivity.class);
                                             startActivity(compassActivity);
                                         }
                                     }
        );
        // On passe de MapsActivité à CameraActivity
        mCamera_btn.setOnClickListener(new View.OnClickListener(){
                                           @Override
                                           public void onClick(View view) {
                                               Intent cameraActivity = new Intent(MapsActivity.this, CameraActivity.class);
                                               startActivity(cameraActivity);
                                           }
                                       }


        );

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
            }, PERMS_CALL_ID);
        }
        // Mise à jour des coordonnées de notre position
        lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500, 0, new LocationListener() {

                    @Override
                    public void onLocationChanged(@NonNull Location location) {
                        if (bool){
                        }
                    }

                    @Override
                    public void onProviderEnabled(@NonNull String provider) {
                        LocationListener.super.onProviderEnabled(provider);
                    }

                    @Override
                    public void onProviderDisabled(@NonNull String provider) {
                        LocationListener.super.onProviderDisabled(provider);
                    }

                    @Override
                    public void onStatusChanged(String provider, int status, Bundle extras) {
                        LocationListener.super.onStatusChanged(provider, status, extras);
                    }
                }

        );
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        gMap = googleMap;
        bool = true;

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
            }, PERMS_CALL_ID);

            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }

        // Créez la base de données et la table de Pokémon si elles n'existent pas
        PokemonDatabaseHelper dbHelper = new PokemonDatabaseHelper(this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();


        // On ajoute les données à notre BDD
        ContentValues values = new ContentValues();
        values.put("name", "Pikachu");
        values.put("latitude", 44.788743);
        values.put("longitude", -0.58703);
        db.insert("pokemon", null, values);

        values.put("name", "Rondoudou");
        values.put("latitude", 44.793499);
        values.put("longitude", -0.583067);
        db.insert("pokemon", null, values);

        // Récupérez les Pokémon de la base de données SQL
        List<Pokemon> pokemonList = getPokemonFromSQLite();

        // Récupérez les images à partir des ressources de l'application
        Bitmap pikachuImage = BitmapFactory.decodeResource(getResources(), R.drawable.pikachu);
        Bitmap rondoudouImage = BitmapFactory.decodeResource(getResources(), R.drawable.rondoudou);

        // Créez une HashMap pour stocker les images associées à chaque nom de Pokémon
        HashMap<String, Bitmap> pokemonImages = new HashMap<>();

        // Ajoutez les images à la HashMap en utilisant le nom du Pokémon comme clé
        pokemonImages.put("Pikachu", pikachuImage);
        pokemonImages.put("Rondoudou", rondoudouImage);

        // Pour chaque Pokémon, ajoutez un marqueur sur la carte
        for (Pokemon pokemon : pokemonList) {
            LatLng pokemonLocation = new LatLng(pokemon.getLatitude(), pokemon.getLongitude());
            String pokemonName = pokemon.getName();
            Bitmap pokemonImage = pokemonImages.get(pokemonName);
            gMap.addMarker(new MarkerOptions().position(pokemonLocation).title(pokemonName).icon(BitmapDescriptorFactory.fromBitmap(pokemonImage)));
        }
        gMap.getUiSettings().setCompassEnabled(true);
        gMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);

        // On paramètre la camera qui permet de se déplacer sur la map
        CameraPosition cameraPosition = new CameraPosition.Builder()
                .target(new LatLng(44.788766, -0.587009))
                .zoom(18)
                .tilt(67.5f)
                .bearing(314)
                .build();
        gMap.moveCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
    }

    private List<Pokemon> getPokemonFromSQLite() {
        List<Pokemon> pokemonList = new ArrayList<>();

        // Ouvrez la base de données et récupérez les Pokémon
        PokemonDatabaseHelper dbHelper = new PokemonDatabaseHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM pokemon", null);

        // Pour chaque ligne de la table, on crée un objet Pokemon et on l'ajoute à la liste
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String name = cursor.getString(1);
                double latitude = cursor.getDouble(2);
                double longitude = cursor.getDouble(3);
                Pokemon pokemon = new Pokemon(id, name, latitude, longitude);
                pokemonList.add(pokemon);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();

        return pokemonList;
    }
            }




